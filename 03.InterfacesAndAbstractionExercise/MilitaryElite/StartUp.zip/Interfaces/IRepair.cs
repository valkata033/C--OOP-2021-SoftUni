﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Interfaces
{
    public interface IRepair
    {
        public string Name { get; set; }

        public int WorkedHours { get; set; }

    }
}
